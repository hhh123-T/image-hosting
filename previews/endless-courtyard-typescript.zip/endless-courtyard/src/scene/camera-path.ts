import { CatmullRomCurve3, Vector3 } from 'three';
export const JOURNEY_DURATION = 48;
const route = new CatmullRomCurve3([
  new Vector3(52, 22, 94),
  new Vector3(33, 13, 57),
  new Vector3(13, 7, 19),
  new Vector3(1, 7, -23),
  new Vector3(-15, 20, -40),
  new Vector3(-72, 53, 24),
  new Vector3(-65, 68, 132),
  new Vector3(30, 37, 142),
], true, 'catmullrom', 0.45);
const gaze = new CatmullRomCurve3([
  new Vector3(-3, 19, -29), new Vector3(0, 15, -24),
  new Vector3(0, 13, -30), new Vector3(0, 16, -80),
  new Vector3(3, 17, -66), new Vector3(0, 14, -26),
  new Vector3(0, 17, -48), new Vector3(0, 17, -26),
], true, 'catmullrom', 0.4);

export function sampleJourney(seconds: number) {
  const t = ((seconds % JOURNEY_DURATION) + JOURNEY_DURATION) % JOURNEY_DURATION / JOURNEY_DURATION;
  return {
    position: route.getPoint(t), target: gaze.getPoint(t),
    chapter: t < 0.33 ? '01 / 水上漫游' : t < 0.62 ? '02 / 穿过画境' : '03 / 无垠之上',
  };
}
