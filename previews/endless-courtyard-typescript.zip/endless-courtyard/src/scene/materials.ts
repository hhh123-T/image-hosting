import {
  CanvasTexture, Color, MeshStandardMaterial, RepeatWrapping, SRGBColorSpace,
} from 'three';

export function seededRandom(seed: number) {
  return () => {
    seed |= 0; seed = seed + 0x6D2B79F5 | 0;
    let t = Math.imul(seed ^ seed >>> 15, 1 | seed);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}

function paintedSurface(seed: number) {
  const random = seededRandom(seed);
  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = 512;
  const context = canvas.getContext('2d')!;
  context.fillStyle = '#cccac1';
  context.fillRect(0, 0, 512, 512);
  // Broad dry-brush strokes establish a surface before the finer impasto grain.
  for (let i = 0; i < 1100; i++) {
    const tone = Math.floor(100 + random() * 150);
    context.fillStyle = `rgba(${tone},${tone},${tone},${0.03 + random() * 0.12})`;
    const x = random() * 512, y = random() * 512;
    context.fillRect(x, y, 1 + random() * 65, 0.5 + random() * 7);
  }
  const pixels = context.getImageData(0, 0, 512, 512);
  for (let i = 0; i < pixels.data.length; i += 4) {
    const n = (random() - 0.5) * 24;
    pixels.data[i] += n; pixels.data[i + 1] += n; pixels.data[i + 2] += n;
  }
  context.putImageData(pixels, 0, 0);
  for (let i = 0; i < 180; i++) {
    context.strokeStyle = random() > 0.5 ? 'rgba(255,255,245,.22)' : 'rgba(48,51,47,.13)';
    context.lineWidth = 0.5 + random() * 1.5;
    context.beginPath();
    const x = random() * 512, y = random() * 512;
    context.moveTo(x, y);
    context.bezierCurveTo(x + 12, y + 1, x + 40, y - 2, x + 60 + random() * 70, y);
    context.stroke();
  }
  const texture = new CanvasTexture(canvas);
  texture.wrapS = texture.wrapT = RepeatWrapping;
  texture.colorSpace = SRGBColorSpace;
  texture.anisotropy = 4;
  return texture;
}

export function createMaterials() {
  const texture = paintedSurface(71);
  const material = (color: string, bumpScale = 0.2) => new MeshStandardMaterial({
    color: new Color(color), map: texture, bumpMap: texture,
    bumpScale, roughness: 0.96, metalness: 0.03,
  });
  return {
    chalk: material('#edeee6', 0.26),
    ivory: material('#e7e7db', 0.2),
    sage: material('#91a69f', 0.16),
    dark: material('#374442', 0.2),
    ochre: material('#ae5838', 0.15),
    copper: material('#88543d', 0.2),
    stone: material('#a6aea2', 0.24),
  };
}
export type ArtMaterials = ReturnType<typeof createMaterials>;
