import { Color, PlaneGeometry, ShaderMaterial } from 'three';
import { Reflector } from 'three/addons/objects/Reflector.js';

export function createWater() {
  const shader = {
    name: 'PaintedWater',
    uniforms: {
      color: { value: new Color('#7d958b') },
      tDiffuse: { value: null },
      textureMatrix: { value: null },
      time: { value: 0 },
    },
    vertexShader: `
      uniform mat4 textureMatrix;
      varying vec4 vUv;
      varying vec3 vWorld;
      void main() {
        vUv = textureMatrix * vec4(position, 1.0);
        vWorld = (modelMatrix * vec4(position, 1.0)).xyz;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }
    `,
    fragmentShader: `
      uniform vec3 color;
      uniform sampler2D tDiffuse;
      uniform float time;
      varying vec4 vUv;
      varying vec3 vWorld;
      void main() {
        vec4 uv = vUv;
        float wave = sin(vWorld.x * .28 + time) * sin(vWorld.z * .41 - time);
        uv.x += wave * .00095 * uv.w;
        uv.y += sin(vWorld.z * .53 + time * 2.0) * .00065 * uv.w;
        vec3 reflection = texture2DProj(tDiffuse, uv).rgb;
        float wash = .5 + .5 * sin(vWorld.z * 5.0 + wave * 3.0);
        vec3 surface = mix(reflection, color, .30);
        surface += wash * .013;
        float distanceFade = smoothstep(120.0, 390.0, length(vWorld.xz));
        surface = mix(surface, vec3(.57, .65, .59), distanceFade * .7);
        gl_FragColor = vec4(surface, 1.0);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }
    `,
  };
  const water = new Reflector(new PlaneGeometry(1600, 1600), {
    textureWidth: 768, textureHeight: 768, clipBias: 0.003,
    color: '#7d958b', multisample: 0, shader,
  });
  water.rotation.x = -Math.PI / 2;
  water.position.y = -0.12;
  const material = water.material as ShaderMaterial;
  return { mesh: water, update: (time: number) => { material.uniforms.time.value = time; } };
}
