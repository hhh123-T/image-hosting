import {
  BackSide, BoxGeometry, BufferGeometry, Color, DirectionalLight, Float32BufferAttribute,
  Fog, Group, HemisphereLight, Mesh, MeshStandardMaterial, Points, PointsMaterial,
  Scene, ShaderMaterial, SphereGeometry, TorusGeometry, Vector3,
} from 'three';
import { createMaterials, seededRandom } from './materials';
import { createWater } from './water';

function createSky() {
  return new Mesh(new SphereGeometry(650, 32, 16), new ShaderMaterial({
    side: BackSide, depthWrite: false,
    uniforms: {},
    vertexShader: `
      varying vec3 vPosition;
      void main() {
        vPosition = position;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }
    `,
    fragmentShader: `
      varying vec3 vPosition;
      float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
      float noise(vec2 p) {
        vec2 i = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f);
        return mix(mix(hash(i), hash(i + vec2(1,0)), f.x), mix(hash(i + vec2(0,1)), hash(i + vec2(1)), f.x), f.y);
      }
      void main() {
        vec3 dir = normalize(vPosition);
        float height = smoothstep(-.06, .72, dir.y);
        vec3 color = mix(vec3(.69,.74,.68), vec3(.43,.55,.52), height);
        float clouds = noise(dir.xz * 7.0 + dir.y * 1.6) * .6 + noise(dir.xz * 21.0) * .25;
        color += (clouds - .3) * .07 * smoothstep(.0,.3,dir.y);
        float glow = pow(max(0.0, dot(dir, normalize(vec3(-.65,.38,.25)))), 5.0);
        color = mix(color, vec3(.90,.82,.68), glow * .42);
        gl_FragColor = vec4(color, 1.0);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }
    `,
  }));
}

export function createWorld() {
  const scene = new Scene();
  scene.background = new Color('#bdc8bb');
  scene.fog = new Fog('#bdc8bb', 90, 345);
  const materials = createMaterials();
  const geometry = new BoxGeometry(1, 1, 1);
  const architecture = new Group();
  scene.add(architecture);
  const floating: { object: Mesh | Group; height: number; phase: number; amount: number }[] = [];
  const random = seededRandom(915);

  const block = (
    x: number, y: number, z: number, width: number, height: number, depth: number,
    material: MeshStandardMaterial, parent: Group = architecture,
  ) => {
    const mesh = new Mesh(geometry, material);
    mesh.position.set(x, y, z);
    mesh.scale.set(width, height, depth);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    parent.add(mesh);
    return mesh;
  };
  const slab = (x: number, y: number, z: number, width: number, depth: number, thick = 1.05) => {
    const group = new Group(); architecture.add(group);
    block(x, y, z, width, thick, depth, materials.sage, group);
    block(x, y - thick / 2 + 0.045, z + depth / 2 - 0.06, width, 0.09, 0.16, materials.dark, group);
    return group;
  };

  // Main motif: chalk walls, an ochre incision, and charcoal uprights lifted from the painting.
  block(-14, 12.2, -24, 8.2, 23.4, 12, materials.chalk);
  block(-19.4, 20, -25, 2.4, 39, 9, materials.dark).rotation.z = 0.018;
  block(-8.6, 13.5, -23.5, 3.3, 26, 5, materials.ochre);
  block(-10.5, 13.5, -20.8, 0.3, 26, 0.5, materials.copper);
  block(12.8, 16.2, -24, 7.5, 31.4, 8, materials.ivory);
  block(18.6, 26.5, -25, 3.5, 53, 11, materials.dark).rotation.z = -0.012;
  block(15.7, 16.2, -19.8, 0.8, 31.4, 0.7, materials.stone);
  const firstLintel = slab(-0.5, 28.2, -24, 39, 13.5, 1.65);
  floating.push({ object: firstLintel, height: 0, phase: 0.2, amount: 0.15 });
  slab(-0.4, 14.1, -21.5, 41, 5.8, 0.8);
  slab(-1, 1.1, -21, 45, 18, 1.8);
  slab(-14.5, 36, -26, 14, 14, 0.8);
  // Thin lines interrupt broad walls like the dark strokes in the painting.
  for (const x of [-17.4, -15.9, 10.4, 13.4]) {
    block(x, 10.2, -17.9, 0.1, 15.3, 0.12, materials.stone);
  }

  // Successive portals make the unpainted spaces in the source into immense courtyards.
  for (let i = 0; i < 7; i++) {
    const z = -62 - i * 33;
    const height = 31 + Math.sin(i * 1.7) * 8 + i * 1.4;
    const span = 34 + i * 3;
    const offset = Math.sin(i * 1.3) * 6;
    block(offset - span / 2, height / 2, z, 5 + i * .45, height, 6, i % 2 ? materials.stone : materials.ivory);
    block(offset + span / 2, height / 2 + 4, z, 4.5, height + 8, 8, i % 2 ? materials.dark : materials.chalk);
    block(offset - span / 2 + 4, height * .47, z + 0.2, 2.4, height * .94, 4, materials.ochre);
    slab(offset, height, z, span + 7, 10, 1.3);
    slab(offset, 1.2, z, span + 20, 17, 1.8);
    if (i < 3) slab(offset, height * .45, z, span + 5, 5.5, .75);
  }

  // Two displaced galleries extend the architecture sideways, beyond the original frame.
  for (const side of [-1, 1]) {
    for (let i = 0; i < 5; i++) {
      const x = side * (43 + i * 21);
      const z = -63 - i * 14 + side * 13;
      const height = 20 + random() * 34;
      block(x, height / 2, z, 6 + random() * 7, height, 8 + random() * 8, i % 3 === 0 ? materials.dark : materials.chalk);
      const lintel = slab(x + side * 5, height - 1, z, 25, 10, 1.1);
      floating.push({ object: lintel, height: 0, phase: i * 1.1 + side, amount: .12 });
      if (i < 3) block(x - side * 5, height * .38, z + 5, 2.7, height * .74, 4, materials.ochre);
      slab(x, .9, z, 20, 18, 1.5);
    }
  }

  // A monumental suspended ring is the one impossible gesture in this otherwise tactile world.
  const ring = new Mesh(new TorusGeometry(17.5, 1.25, 12, 112), materials.ivory);
  ring.position.set(-19, 49, -80);
  ring.rotation.set(0.06, -0.1, -0.12);
  ring.castShadow = true;
  scene.add(ring);
  floating.push({ object: ring, height: 49, phase: 0, amount: .3 });
  const ringInset = new Mesh(new TorusGeometry(17.5, 0.19, 8, 112), materials.ochre);
  ringInset.position.set(-19, 49, -78.78);
  ringInset.rotation.copy(ring.rotation);
  scene.add(ringInset);
  floating.push({ object: ringInset, height: 49, phase: 0, amount: .3 });

  // A stairway that hangs in the air; its scale becomes visible on the rising shot.
  for (let i = 0; i < 38; i++) {
    const step = slab(-31 - Math.sin(i * .07) * 4, 4.6 + i * .58, 4 - i * 2.5, 7.5, 2.7, .28);
    step.rotation.y = -0.07;
  }
  block(-33, 2, 12, 24, 3.4, 24, materials.stone);
  slab(-39, 4.2, 14, 30, 16, .8);

  // Broken horizontal brush marks become low, stepping islands across the water.
  for (let i = 0; i < 12; i++) {
    const x = -15 + Math.sin(i * .64) * 12;
    const z = 35 - i * 6;
    const stone = block(x, .34 + random() * .12, z, 4 + random() * 8, .4 + random() * .5, 1.5 + random() * 2.5, i % 3 ? materials.sage : materials.dark);
    stone.rotation.y = (random() - .5) * .3;
  }
  for (let i = 0; i < 28; i++) {
    const x = (random() - .5) * 430;
    const z = -230 - random() * 170;
    const height = 18 + random() * 90;
    block(x, height / 2, z, 4 + random() * 12, height, 5 + random() * 15, i % 4 ? materials.stone : materials.dark);
  }

  scene.add(createSky());
  scene.add(new HemisphereLight('#f2f3e9', '#536a63', 2.2));
  const sunlight = new DirectionalLight('#f3f3df', 2.8);
  sunlight.position.set(-65, 95, 40);
  sunlight.target.position.set(0, 0, -55);
  sunlight.castShadow = true;
  sunlight.shadow.mapSize.set(1536, 1536);
  Object.assign(sunlight.shadow.camera, { left: -150, right: 150, top: 130, bottom: -110, near: 1, far: 300 });
  sunlight.shadow.bias = -0.0004;
  sunlight.shadow.normalBias = 0.12;
  scene.add(sunlight, sunlight.target);
  const fill = new DirectionalLight('#c8dad4', .6);
  fill.position.set(55, 35, -70);
  scene.add(fill);

  const water = createWater(); scene.add(water.mesh);
  const dustGeometry = new BufferGeometry();
  const positions: number[] = [];
  for (let i = 0; i < 220; i++) positions.push((random() - .5) * 170, random() * 60 + 1, -random() * 210 + 45);
  dustGeometry.setAttribute('position', new Float32BufferAttribute(positions, 3));
  const dust = new Points(dustGeometry, new PointsMaterial({ color: '#f4e5c5', size: .12, transparent: true, opacity: .4, depthWrite: false }));
  scene.add(dust);

  return {
    scene,
    update(time: number) {
      // All movement is periodic with the camera loop, including the ripples.
      const phase = time / 48 * Math.PI * 2;
      for (const item of floating) item.object.position.y = item.height + Math.sin(phase + item.phase) * item.amount;
      dust.position.x = Math.sin(phase) * 1.4;
      dust.position.y = Math.cos(phase) * .45;
      water.update(phase);
    },
    dispose() {
      water.mesh.dispose();
      const geometries = new Set<BufferGeometry>();
      const mats = new Set<MeshStandardMaterial | ShaderMaterial | PointsMaterial>();
      scene.traverse(object => {
        if (object instanceof Mesh || object instanceof Points) {
          geometries.add(object.geometry);
          const list = Array.isArray(object.material) ? object.material : [object.material];
          for (const mat of list) mats.add(mat as MeshStandardMaterial);
        }
      });
      for (const geo of geometries) geo.dispose();
      materials.chalk.map?.dispose();
      for (const mat of mats) mat.dispose();
      sunlight.shadow.dispose();
    },
  };
}
